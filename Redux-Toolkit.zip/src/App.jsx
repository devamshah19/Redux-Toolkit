import { Container } from '@chakra-ui/react'
import './App.css'
import { DisplayEmployees } from './DisplayEmployees'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { EmployeeLogin } from './EmployeeLogin';
import EmployeeInfo from './EmployeeInfo';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={
          <Container padding={10}>
            <EmployeeLogin />
          </Container>
        } />
        <Route exact path="/displayemployees" element={<DisplayEmployees />} />
        <Route exact path="/employeeinfo" element={<EmployeeInfo />} />

      </Routes>
    </BrowserRouter>
  )
}

export default App