import { useEffect } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  Heading,
  StackDivider,
  Stack,
  Box,
  Text,
  Container,
  Avatar,
  HStack
} from "@chakra-ui/react";
import { useLocation, useNavigate } from "react-router-dom";

const EmployeeInfo = () => {

    const {state} = useLocation()
    const navigateTo = useNavigate()
    useEffect(()=>{
        if(state === null) navigateTo("/")
    }, [state])

  return (
    <Container marginTop={'5%'}>
        <Card contentEditable={false}>
        <HStack marginLeft={'5'}>
            <Avatar src={state?.avatar} size={'lg'} />
            <CardHeader>
                <Heading size="md">{state?.name}</Heading>
            </CardHeader>
        </HStack>

        <CardBody marginLeft={5}>
            <Stack divider={<StackDivider />} spacing="4">
            <Box>
                <Heading size="xs" textTransform="uppercase">
                Email
                </Heading>
                <Text pt="2" fontSize="sm">
                    { state?.email }
                </Text>
            </Box>
            <Box>
                <Heading size={"sm"} textTransform="uppercase">
                Salary
                </Heading>
                <Text pt="2" fontSize="sm">
                    $ {state?.salary}
                </Text>
            </Box>
            <Box>
                <Heading size="xs" textTransform="uppercase">
                Address
                </Heading>
                <Text pt="2" fontSize="sm">
                    { state?.address }
                </Text>
            </Box>
            <Box>
                <Heading size="xs" textTransform="uppercase">
                Designation
                </Heading>
                <Text pt="2" fontSize="sm">
                    { state?.designation }
                </Text>
            </Box>
            <Box>
                <Heading size="xs" textTransform="uppercase">
                Description
                </Heading>
                <Text pt="2" fontSize="sm">
                    { state?.description }
                </Text>
            </Box>
            </Stack>
        </CardBody>
        </Card>
    </Container>
  );
};

export default EmployeeInfo;
